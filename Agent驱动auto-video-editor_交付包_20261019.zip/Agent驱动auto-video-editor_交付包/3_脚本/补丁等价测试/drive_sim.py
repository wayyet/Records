"""用替身模块验证补丁:原版 / 补丁版在同样输入下的行为。只用标准库。

用法:python3 -I drive_sim.py <sim 目录>     (sim 目录里有 storyline_capabilities/ 包)
输出一个 JSON:每个场景 → 返回值 + 记录到的 chat 调用。
"""
import json
import sys

sys.path.insert(0, sys.argv[1])

from storyline_capabilities import vlm_client as V  # noqa: E402
from storyline_capabilities.select_bgm import select_bgm  # noqa: E402
from storyline_capabilities.understand_clips import understand_clips  # noqa: E402


class Rec:
    """记录每次调用的假 client(模拟 Agent 闸门)。"""

    def __init__(self, tag):
        self.tag = tag
        self.calls = []

    def chat(self, *, system_prompt, user_prompt, media=None, json_schema=None,
             temperature=0.3, top_p=0.9, max_tokens=4096):
        self.calls.append({"sys": system_prompt, "media": media,
                           "has_schema": json_schema is not None})
        if system_prompt.endswith("system_overall"):
            return f"[{self.tag}] 总体:一个好镜头"
        if json_schema is not None and "bgm_id" in json.dumps(json_schema):
            return json.dumps({"bgm_id": "b2", "reason": f"[{self.tag}] 节奏合适"}, ensure_ascii=False)
        return json.dumps({"caption": f"[{self.tag}] 好镜头", "aes_score": 0.8}, ensure_ascii=False)


SPLIT = {"shots": {"m1": [{"clip_id": "c1", "kind": "video",
                           "source_ref": {"media_id": "m1", "start": 0, "end": 2000}}]}}
MEDIA = {"media": [{"media_id": "m1", "path": "x.mp4"}]}
LIB = [
    {"bgm_id": "b1", "path": "", "mood": ["happy"], "tempo": "fast", "duration_ms": 30000, "beat_period_ms": 500},
    {"bgm_id": "b2", "path": "", "mood": ["happy", "energetic"], "tempo": "fast", "duration_ms": 30000,
     "beat_period_ms": 500},
]


def uc(**kw):
    return understand_clips(split_shots_artifact=SPLIT, media_artifact=MEDIA, **kw)


def bgm(**kw):
    r = select_bgm(user_request="欢快 活力", library=LIB, **kw)
    return {k: r[k] for k in ("bgm_ref", "method", "reason", "stub")}


def calls(rec):
    return [{"sys": c["sys"], "media": c["media"], "has_schema": c["has_schema"]} for c in rec.calls]


out = {}

# 场景 A:没装任何 client(默认 Stub)——补丁不应改变任何输出
V.set_default_client(None)
out["A_default_stub"] = {"understand_clips": uc(), "select_bgm": bgm()}

# 场景 B:装了全局默认 client(就是 Agent 闸门的接法)
for name, fn in (("B_understand_clips", uc), ("B_select_bgm", bgm)):
    rec = Rec("default")
    V.set_default_client(rec)
    out[name] = {"result": fn(), "calls": calls(rec)}

# 场景 C:显式传 client——永远优先于全局默认
for name, fn in (("C_understand_clips", uc), ("C_select_bgm", bgm)):
    g, e = Rec("global"), Rec("explicit")
    V.set_default_client(g)
    out[name] = {"result": fn(client=e), "explicit_calls": len(e.calls), "global_calls": len(g.calls)}

print(json.dumps(out, ensure_ascii=False, sort_keys=True, indent=1))
