# agent_gate_kit

让 Claude Code / MiniMax Code 直接驱动 `auto-video-editor` 的参考实现。
完整设计和执行步骤见《Agent程序直接驱动auto-video-editor_设计与执行计划》。

## 里面有什么

| 路径 | 是什么 |
|---|---|
| `agent_gate/` | 新增的包。**复制到仓库根目录** |
| `agent_gate_llm_seam.patch` | 给仓库 2 个文件打的补丁（2 个文件，+11 −5 行） |
| `requirements-agent-gate.txt` | 本方案新增的 2 个依赖，精确版本 |
| `tests/`、`fixtures/` | 自动化测试和玩具图（89 个测试） |

## 最短用法（PowerShell；变量的定义见设计文档 §11）

```powershell
& $PY -m pip install -r "$KIT\requirements-agent-gate.txt"
Copy-Item -Recurse -Force "$KIT\agent_gate" $REPO
Set-Location $REPO
git apply --check "$KIT\agent_gate_llm_seam.patch"
git apply "$KIT\agent_gate_llm_seam.patch"
& $PY -m agent_gate --help
```

跑测试（在 `$KIT` 里）：`& $PY -m pytest tests -q -p no:cacheprovider`。没装 `claude` 或 `mcode` 的测试会自动跳过；需要 `ffmpeg` 在 `PATH` 里。
