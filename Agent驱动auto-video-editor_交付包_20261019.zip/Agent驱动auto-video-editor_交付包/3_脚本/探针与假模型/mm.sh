#!/usr/bin/env bash
# 用法: mm.sh NAME SCRIPT_JSON PROJECT_DIR [mcode 参数...]   (固定端口 18082:provider 的 base-url 里写死了)
# 起假模型 → 在隔离环境里跑真实 mcode → 收日志 → 关假模型
S=/tmp/claude-0/-home-claude/8d8266ac-1614-53a6-a397-b6195d29cd20/scratchpad
NAME=$1; SCRIPT=$2; PROJ=$3; shift 3
PORT=18082
LOG=$S/harness/log_$NAME.jsonl; rm -f "$LOG"
python3 $S/harness/mockllm2.py "$PORT" "$SCRIPT" "$LOG" > $S/harness/mock_$NAME.out 2>&1 &
MPID=$!
sleep 1
cd "$PROJ" || exit 9
env -i PATH="/opt/node22/bin:/usr/local/bin:/usr/bin:/bin" HOME=$S/mm/home MOCK_KEY=sk-mock-local \
  NO_PROXY=127.0.0.1,localhost no_proxy=127.0.0.1,localhost $EXTRA_ENV \
  timeout ${MM_TIMEOUT:-300} $S/mm/node_modules/.bin/mcode "$@" < /dev/null > $S/out/$NAME.json 2> $S/out/$NAME.err
echo "mcode exit=$?"
kill $MPID 2>/dev/null
wait $MPID 2>/dev/null
echo "mock log lines: $(wc -l < "$LOG")"
