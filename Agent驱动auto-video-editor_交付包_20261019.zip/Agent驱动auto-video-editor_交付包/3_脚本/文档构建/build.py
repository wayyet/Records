#!/usr/bin/env python3
"""构建文档:设计与执行计划 md、参考实现源码 md、压缩包、补丁。

原则:文档里的数字、表格、样例、配置、命令,都从真实代码和真实输出里取,不手写。
    - 常量 / 子命令 / MCP 工具 / 文件行数 / 测试数  ← 直接读代码、读 pytest 的 junit 结果
    - 补丁 / 差异统计                                 ← 在审计克隆的副本上真实 apply
    - 任务 / 状态 / 事件样例                           ← 真实运行 CLI 得到的输出(只换路径)
    - 配置文件内容                                     ← 调用 scaffold 的真实函数生成
构建时还会做一致性断言:占位符全部被替换;文档里写的命令行参数都真实存在;§ 引用都能找到标题。

用法(必须用装了 mcp / jsonschema 的 python):
    <venv>/bin/python build.py
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path, PureWindowsPath
from typing import Any
from xml.etree import ElementTree as ET

sys.dont_write_bytecode = True

S = Path("/tmp/claude-0/-home-claude/8d8266ac-1614-53a6-a397-b6195d29cd20/scratchpad")
KIT = S / "ref_impl"
DOC = S / "doc"
PARTS = DOC / "parts"
OUT = DOC / "out"
PATCH = S / "patch" / "agent_gate_llm_seam.patch"
CLONE = Path("/home/claude/src/auto-video-editor")
SAMPLES = DOC / "samples"
TESTRUN = DOC / "testrun.json"
CHECKS = DOC / "checks.json"

DOC_NAME = "Agent程序直接驱动auto-video-editor_设计与执行计划.md"
SRC_NAME = "Agent程序直接驱动auto-video-editor_参考实现源码.md"
ZIP_NAME = "agent_gate_kit.zip"
PATCH_NAME = "agent_gate_llm_seam.patch"

for var in ("AGENT_GATE_HEARTBEAT_S", "AGENT_GATE_STALE_AFTER_S", "AGENT_GATE_CLI_TIMEOUT_S"):
    os.environ.pop(var, None)          # 文档里的默认值必须是代码里的真默认值,不是测试环境改过的
sys.path.insert(0, str(KIT))

from agent_gate import cli, cli_client, drive, mcp_server, protocol, scaffold  # noqa: E402


def read(p: Path | str) -> str:
    return Path(p).read_text(encoding="utf-8")


def sh(cmd: list[str], cwd: Path | None = None, check: bool = True, env: dict | None = None) -> str:
    cp = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, encoding="utf-8", env=env)
    if check and cp.returncode != 0:
        raise RuntimeError(f"命令失败 {cmd}:\n{cp.stdout}\n{cp.stderr}")
    return cp.stdout


def fmt_num(x: float | int) -> str:
    return str(int(x)) if float(x).is_integer() else str(x)


def md_cell(s: str) -> str:
    return s.replace("|", "\\|").replace("\n", " ")


# ====================================================================== 路径换成 Windows 示例
def to_win(s: str) -> str:
    """沙箱路径 → Windows 示例路径(Windows 上 str(Path) 就是反斜杠)。"""
    pre_vid = str(SAMPLES / "demo.mp4")
    pre_out = str(SAMPLES / "out")
    if s == pre_vid:
        return r"D:\videos\demo.mp4"
    if s.startswith(pre_out):
        return r"D:\work\auto-video-editor\outputs" + s[len(pre_out):].replace("/", "\\")
    return s


def walk(obj: Any, fn) -> Any:
    if isinstance(obj, dict):
        return {k: walk(v, fn) for k, v in obj.items()}
    if isinstance(obj, list):
        return [walk(v, fn) for v in obj]
    if isinstance(obj, str):
        return fn(obj)
    return obj


def sample_json(name: str, *, trim_frames: int | None = None) -> str:
    obj = walk(json.loads(read(SAMPLES / name)), to_win)
    if trim_frames is not None:
        obj["frames"] = obj["frames"][:trim_frames]
    return json.dumps(obj, ensure_ascii=False, indent=2)


# ====================================================================== 生成各个片段
def gen_patch() -> dict[str, str]:
    """在审计克隆的副本上真实 apply / 反向 apply,取统计;克隆本身不动。"""
    patch_text = read(PATCH)
    before = sh(["git", "status", "--porcelain"], cwd=CLONE)
    head = sh(["git", "rev-parse", "--short", "HEAD"], cwd=CLONE).strip()
    tmp = Path(tempfile.mkdtemp(prefix="patchcheck_"))
    try:
        repo = tmp / "repo"
        shutil.copytree(CLONE, repo, symlinks=True)
        sh(["git", "apply", "--check", str(PATCH)], cwd=repo)
        numstat = sh(["git", "apply", "--numstat", str(PATCH)], cwd=repo).strip().splitlines()
        sh(["git", "apply", str(PATCH)], cwd=repo)
        diffstat = sh(["git", "diff", "--stat"], cwd=repo).rstrip("\n")
        files = [l.split("\t")[-1] for l in sh(["git", "diff", "--numstat"], cwd=repo).strip().splitlines()]
        for f in files:                                           # 打补丁后能编译
            sh([sys.executable, "-m", "py_compile", str(repo / f)])
        sh(["git", "apply", "-R", str(PATCH)], cwd=repo)          # 反向撤销后回到原样
        assert sh(["git", "status", "--porcelain"], cwd=repo) == before, "git apply -R 后工作区没有回到原样"
        assert sh(["git", "diff"], cwd=repo) == "", "git apply -R 后还有差异"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    assert sh(["git", "status", "--porcelain"], cwd=CLONE) == before, "审计克隆被改动了!"
    add = sum(int(l.split("\t")[0]) for l in numstat)
    dele = sum(int(l.split("\t")[1]) for l in numstat)
    assert len(files) == 2, files
    return {
        "PATCH_DIFF": patch_text.rstrip("\n"),
        "PATCH_DIFFSTAT": diffstat,
        "PATCH_STAT": f"{len(files)} 个文件，+{add} −{dele} 行",
        "PATCH_FILES": ", ".join(files),
        "CLONE_HEAD": head,
    }


def gen_constants_table() -> str:
    c = cli_client.ClaudeCLIClient()
    rows = [
        ("单任务最长等待", f"{fmt_num(protocol.DEFAULT_TIMEOUT_S)} 秒", "`protocol.DEFAULT_TIMEOUT_S`"),
        ("轮询结果文件的间隔", f"{fmt_num(protocol.DEFAULT_POLL_S)} 秒", "`protocol.DEFAULT_POLL_S`"),
        ("不合格最多提交次数", f"{protocol.DEFAULT_MAX_ATTEMPTS} 次", "`protocol.DEFAULT_MAX_ATTEMPTS`"),
        ("心跳间隔", f"{fmt_num(protocol.HEARTBEAT_S)} 秒（环境变量 `AGENT_GATE_HEARTBEAT_S`）", "`protocol.HEARTBEAT_S`"),
        ("判定崩溃", f"心跳 {fmt_num(protocol.STALE_AFTER_S)} 秒没更新（环境变量 `AGENT_GATE_STALE_AFTER_S`）",
         "`protocol.STALE_AFTER_S`"),
        ("`gate_next_tasks` 单次最长等待", f"{fmt_num(mcp_server.MAX_WAIT_S)} 秒", "`mcp_server.MAX_WAIT_S`"),
        ("单次返回图片上限", f"{mcp_server.MAX_IMAGES} 张", "`mcp_server.MAX_IMAGES`"),
        ("MCP 工具超时（写进 `.mcp.json`）", f"{scaffold.MCP_TOOL_TIMEOUT_MS} 毫秒", "`scaffold.MCP_TOOL_TIMEOUT_MS`"),
        ("方案 B 单次调用超时", f"{fmt_num(c.timeout_s)} 秒（环境变量 `AGENT_GATE_CLI_TIMEOUT_S`）",
         "`cli_client._CLIClient`"),
    ]
    out = ["| 常量 | 值 | 位置 |", "|---|---|---|"]
    out += [f"| {a} | {b} | {c_} |" for a, b, c_ in rows]
    return "\n".join(out)


def subparsers() -> dict[str, argparse.ArgumentParser]:
    ap = cli.build_parser()
    sp = next(a for a in ap._actions if isinstance(a, argparse._SubParsersAction))
    return dict(sp.choices)


def flags_of(p: argparse.ArgumentParser) -> set[str]:
    return {s for a in p._actions for s in a.option_strings if s.startswith("--")}


CLI_ROWS = {
    "init": ("你（一次性）", "生成操作员目录",
             "`--project-dir --repo-root` `[--outputs-root --graph-factory --python --env --with-human-tool --force]`"),
    "mcode-lock": ("你（一次性，仅 MiniMax Code）", "生成加锁的 mcode 配置", "`--base --out` `[--force]`"),
    "start": ("Agent / 你", "拉起 worker，开始一次新运行；崩溃后加 `--continue` 从检查点继续",
              "`--thread-id` `[--outputs-root --graph-factory --video --initial-state-file --backend --continue]`"),
    "drive": ("你", "无人值守：反复拉起 Agent 会话，直到完成或停在人工关卡",
              "`--thread-id --agent --project-dir` `[--video --initial-state-file --batch --max-sessions --max-wall-s "
              "--session-timeout-s --agent-bin --model --permission --mcode-config]`"),
    "worker": ("内部", "在当前进程里跑图（由 `start` / `resume` / `drive` 拉起，不要手动调）", "—"),
    "status": ("Agent / 你", "看状态和 `next_action`", "`--thread-id`"),
    "tasks": ("Agent / 你", "列出待办任务（可等待）", "`--thread-id` `[--limit --wait-s]`"),
    "task": ("Agent / 你", "看单个任务全文", "`--thread-id --task-id`"),
    "submit": ("Agent / 你", "提交一个任务的答案", "`--thread-id --task-id` + `--answer` 或 `--answer-file`（二选一）"),
    "submit-batch": ("Agent / 你", "一次提交多个答案", "`--thread-id --results-file`"),
    "events": ("你", "看最近的事件日志", "`--thread-id` `[--limit]`"),
    "resume": ("**只给人**", "通过人工关卡后继续运行；默认要求在交互终端里运行",
               "`--thread-id --checkpoint` `[--value --backend --force-no-tty --graph-factory]`"),
}


def gen_cli() -> dict[str, str]:
    subs = subparsers()
    assert set(subs) == set(CLI_ROWS), (set(subs) ^ set(CLI_ROWS))
    out = ["| 子命令 | 给谁用 | 作用 | 主要参数 |", "|---|---|---|---|"]
    for name in subs:                                   # 保持 argparse 里的注册顺序
        who, what, args = CLI_ROWS[name]
        for fl in re.findall(r"--[a-z][a-z-]*", args):
            assert fl in flags_of(subs[name]), f"表里写了 {name} {fl},但代码里没有"
        out.append(f"| `{name}` | {who} | {what} | {args} |")
    env = dict(os.environ, COLUMNS="100", PYTHONUTF8="1")
    help_txt = sh([sys.executable, "-m", "agent_gate", "--help"], cwd=KIT, env=env).rstrip("\n")
    return {"CLI_TABLE": "\n".join(out), "CLI_SUBCOMMANDS": help_txt, "n_sub": str(len(subs))}


MCP_NOTES = {
    "run_start": "每个新视频用新的 `thread_id`（见下）",
    "run_status": "返回里有 `submissions_dir`",
    "gate_next_tasks": "一次最多带 12 张图；放不下的任务留到下一次（`deferred_tasks`）",
    "gate_get_task": "任务 prompt 被截断时用",
    "gate_submit_result": "返回 `errors` 和 `attempts_left`",
    "gate_submit_batch": "只读 `submissions_dir` 下的文件；需要 Agent 有写文件工具",
    "human_resume": "**默认不注册**。`init --with-human-tool` 才有；带 `requiresUserInteraction` 标记；Agent 不得调用",
}


def gen_mcp_tools() -> str:
    tmp = tempfile.mkdtemp(prefix="mcpscan_")
    try:
        srv = mcp_server.build_server(tmp, "graph:build_graph", with_human_tool=True)
        tools = asyncio.run(srv.list_tools())
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    by = {t.name: t for t in tools}
    assert set(by) == set(MCP_NOTES), set(by) ^ set(MCP_NOTES)
    assert by["human_resume"].meta == {"anthropic/requiresUserInteraction": True}, by["human_resume"].meta
    default_tools = asyncio.run(mcp_server.build_server(tempfile.gettempdir(), "graph:build_graph").list_tools())
    assert {t.name for t in default_tools} == set(MCP_NOTES) - {"human_resume"}
    out = ["| 工具 | 参数（`?` = 可选） | 作用 | 备注 |", "|---|---|---|---|"]
    for t in tools:
        props = (t.inputSchema or {}).get("properties", {})
        req = set((t.inputSchema or {}).get("required", []))
        params = ", ".join(f"`{k}`" + ("" if k in req else "?") for k in props)
        desc = (t.description or "").strip().split("\n\n")[0].replace("\n", " ")
        out.append(f"| `{t.name}` | {params} | {md_cell(desc)} | {MCP_NOTES[t.name]} |")
    return "\n".join(out)


def gen_configs() -> dict[str, str]:
    """用 scaffold 的真实函数生成配置;把路径函数临时换成 Windows 风格,得到可直接参考的示例。"""
    saved = (scaffold.posix, scaffold.exe_posix, scaffold._pythonpath)
    scaffold.posix = lambda p: str(p).replace("\\", "/")
    scaffold.exe_posix = lambda p: str(p).replace("\\", "/")
    scaffold._pythonpath = lambda repo_root: "D:/work/auto-video-editor"
    try:
        mcp = scaffold.build_mcp_json(
            python=r"D:\work\auto-video-editor\.venv\Scripts\python.exe",
            repo_root=PureWindowsPath(r"D:\work\auto-video-editor"),
            outputs_root=PureWindowsPath(r"D:\work\auto-video-editor\outputs"),
            graph_factory="graph:build_graph", extra_env={"STORYLINE_MODE": "auto"})
        settings = scaffold.build_claude_settings(
            python=r"D:\work\auto-video-editor\.venv\Scripts\python.exe",
            hook_path=PureWindowsPath(r"D:\work\video-ops\.claude\hooks\guard_hook.py"))
    finally:
        scaffold.posix, scaffold.exe_posix, scaffold._pythonpath = saved
    return {
        "MCP_JSON": json.dumps(mcp, ensure_ascii=False, indent=2),
        "SETTINGS_JSON": json.dumps(settings, ensure_ascii=False, indent=2),
        "RULES_TEXT": scaffold.RULES_TEXT.rstrip("\n"),
        "MCODE_LOCK_SNIPPET": scaffold.MCODE_LOCK_SNIPPET.rstrip("\n"),
        "BATCH_PROMPT": drive.BATCH_PROMPT.rstrip("\n"),
    }


FILE_DESC = {
    "__init__.py": "包标记",
    "__main__.py": "`python -m agent_gate` 入口",
    "protocol.py": "常量、时间戳、`task_id` 计算",
    "validate.py": "解析 JSON、JSON Schema 校验",
    "mailbox.py": "文件信箱：任务、结果、错误、事件、状态",
    "media.py": "任务附带的画面：图片引用、视频抽帧",
    "gate_client.py": "`GateLLMClient`：写任务文件，阻塞等待答案",
    "service.py": "服务层：任务视图、提交校验、状态汇总、长轮询、图片预算",
    "runner.py": "worker 进程、拉起与恢复、同步版 resume",
    "factory.py": "按后端名造 LLM 客户端",
    "mcp_server.py": "`video-agent` MCP 服务",
    "cli.py": "命令行入口（12 个子命令）",
    "cli_client.py": "方案 B：`claude -p` / `mcode exec` 适配器",
    "launcher.py": "无人值守地拉起 Agent 会话",
    "drive.py": "`drive` 循环、退出码、会话提示词",
    "guard_hook.py": "Claude Code 的 PreToolUse 钩子（软护栏）",
    "scaffold.py": "`init`（生成操作员目录）、`mcode-lock`、操作规则文本",
}


def kit_files() -> list[Path]:
    """压缩包里的全部文件(相对 KIT 的路径,排序固定)。"""
    out: list[Path] = []
    for sub in ("agent_gate", "fixtures", "tests"):
        for p in sorted((KIT / sub).rglob("*")):
            if p.is_file() and "__pycache__" not in p.parts and ".pytest_cache" not in p.parts \
                    and p.suffix not in (".pyc", ".pyo"):
                out.append(p.relative_to(KIT))
    return out


def lines_of(p: Path) -> int:
    return len(read(p).splitlines())


def gen_file_table() -> dict[str, str]:
    pkg = sorted((KIT / "agent_gate").glob("*.py"), key=lambda p: p.name)
    assert {p.name for p in pkg} == set(FILE_DESC), {p.name for p in pkg} ^ set(FILE_DESC)
    order = list(FILE_DESC)
    pkg.sort(key=lambda p: order.index(p.name))
    assert "12 个子命令" not in FILE_DESC["cli.py"] or len(subparsers()) == 12
    out = ["| 文件 | 行数 | 作用 |", "|---|---|---|"]
    total = 0
    for p in pkg:
        n = lines_of(p)
        total += n
        out.append(f"| `agent_gate/{p.name}` | {n} | {FILE_DESC[p.name]} |")
    out.append(f"| **合计** | **{total}** | |")
    tests = sorted((KIT / "tests").glob("*.py"))
    fx = sorted((KIT / "fixtures").rglob("*.py"))
    extra = (f"测试和测试辅助代码另有 {sum(lines_of(p) for p in tests)} 行（`tests/`，{len(tests)} 个文件），"
             f"玩具图和替身模块 {sum(lines_of(p) for p in fx)} 行（`fixtures/`，{len(fx)} 个文件）。")
    return {"FILE_TABLE": "\n".join(out) + "\n\n" + extra, "PKG_LINES": str(total)}


TEST_DESC = {
    "test_gate": "闸门本体：`task_id`、校验、重放、重试、超时、抽帧；`interrupt()` 会被吞；worker 子进程 + 玩具图端到端；崩溃后恢复；`resume` 防护",
    "test_mcp": "MCP 服务：工具清单、放行工具标记、图片、校验",
    "test_cli_client": "方案 B：命令形状、两个适配器的结构化输出 / 图片 / 重试 / 超时杀进程树；worker 用 `--backend` 跑完整张玩具图",
    "test_drive": "`drive`：多会话、停在关卡、无进展、预算、自动重启 worker；真实 claude / mcode / mcode 加锁配置端到端",
    "test_scaffold": "`init` / `mcode-lock` / `--env` / 操作规则 / 钩子规则 / worker 在仓库根目录运行",
    "test_agent_security": "Claude 隔离三开关、启动竞态、`deny`、钩子、`requiresUserInteraction`；两个程序的 MCP 超时；mcode shell 无 TTY",
    "test_images": "图片预算与分批；BOM 容忍；12 张真实尺寸画面帧到达 claude / mcode",
}


def load_testrun() -> dict[str, Any]:
    return json.loads(read(TESTRUN))


def gen_tests(tr: dict[str, Any]) -> dict[str, str]:
    per = tr["per_file"]
    assert set(per) == set(TEST_DESC), set(per) ^ set(TEST_DESC)
    out = ["| 测试文件 | 个数 | 验证什么 |", "|---|---|---|"]
    for k in TEST_DESC:
        out.append(f"| `{k}.py` | {per[k]} | {TEST_DESC[k]} |")
    out.append(f"| **合计** | **{tr['total']}** | |")
    assert sum(per.values()) == tr["total"]
    assert tr["failures"] == 0 and tr["errors"] == 0 and tr["skipped"] == 0, tr
    m, s = divmod(int(round(tr["time_s"])), 60)
    return {
        "TEST_TABLE": "\n".join(out), "TEST_TOTAL": str(tr["total"]),
        "TEST_TIME": f"{m} 分 {s} 秒", "CLAUDE_VER": tr["claude"], "MCODE_VER": tr["mcode"],
        "PY_VER": tr["python"],
    }


def gen_samples() -> dict[str, str]:
    events = [json.loads(l) for l in read(SAMPLES / "out/demo/agent_gate/events.jsonl").splitlines() if l.strip()]
    ev_lines = "\n".join(json.dumps(e, ensure_ascii=False) for e in events[:8])
    return {
        "TASK_FILE_JSON": sample_json("out/demo/agent_gate/tasks/t_eda474ffdc4c5971.task.json", trim_frames=2),
        "SUBMIT_BAD_JSON": sample_json("submit_bad.json"),
        "STATUS_GATE1_JSON": sample_json("status_gate1.json"),
        "EVENTS_SAMPLE": ev_lines,
    }


def gen_checks() -> dict[str, str]:
    if not CHECKS.exists():
        return {"DOC_CHECKS": "文档自检（尚未运行）", "DOC_CHECKS_TABLE": "（尚未运行）"}
    ck = json.loads(read(CHECKS))
    rows = ["| 检查 | 范围 | 结果 |", "|---|---|---|"]
    for r in ck["rows"]:
        rows.append(f"| {r['name']} | {r['scope']} | {r['result']} |")
    return {"DOC_CHECKS": ck["summary"], "DOC_CHECKS_TABLE": "\n".join(rows)}


# ====================================================================== 组装 + 断言
PLACEHOLDER = re.compile(r"\{\{([A-Z][A-Z0-9_]*)\}\}")


def substitute(text: str, values: dict[str, str]) -> str:
    missing = sorted({m for m in PLACEHOLDER.findall(text) if m not in values})
    assert not missing, f"没有生成器的占位符:{missing}"
    return PLACEHOLDER.sub(lambda m: values[m.group(1)], text)


def check_doc(doc: str, tr: dict[str, Any]) -> None:
    assert "{{" not in doc.replace("{{", "", 0) or True
    left = [m for m in PLACEHOLDER.findall(doc)]
    assert not left, f"还有没替换的占位符:{left}"

    # 1) 文档里写死的数字 == 代码里的真值
    pairs = [
        ("每 5 秒", protocol.HEARTBEAT_S == 5.0), ("超过 30 秒", protocol.STALE_AFTER_S == 30.0),
        ("30 分钟", protocol.DEFAULT_TIMEOUT_S == 1800.0), ("最多提交 3 次", protocol.DEFAULT_MAX_ATTEMPTS == 3),
        ("12 张", mcp_server.MAX_IMAGES == 12), ("90 秒", mcp_server.MAX_WAIT_S == 90.0),
    ]
    for needle, ok in pairs:
        assert needle in doc, f"文档里找不到「{needle}」"
        assert ok, f"文档写了「{needle}」,但代码里的值不一样"

    # 2) drive 参数默认值、退出码
    dp = subparsers()["drive"]
    defaults = {s: a.default for a in dp._actions for s in a.option_strings}
    for flag in ("--batch", "--max-sessions", "--max-wall-s", "--session-timeout-s", "--permission"):
        d = defaults[flag]
        want = f"| `{flag}` | {fmt_num(d) if isinstance(d, (int, float)) else '`' + str(d) + '`'} |"
        assert want in doc, f"drive 参数表里没有:{want}"
    names = {0: "done", 1: "failed", 2: "need_input", 3: "budget", 4: "stalled", 5: "crashed", 10: "ask_human"}
    assert {v: k for k, v in names.items()} == drive.EXIT_CODES, drive.EXIT_CODES
    for code, name in names.items():
        assert re.search(rf"\|\s*{code}\s*\|\s*`{name}`\s*\|", doc), f"退出码表里没有 {code} {name}"

    # 3) 文档里的 agent_gate 命令:子命令、参数都必须真实存在;必填参数不能漏
    subs = subparsers()
    flat = doc.replace("`\n", " ")                                # PowerShell 续行
    n_cmds = 0
    for m in re.finditer(r"-m agent_gate (?!\.)([a-z][a-z-]*)([^\n]*)", flat):
        sub, rest = m.group(1), m.group(2)
        if sub not in subs:
            raise AssertionError(f"文档里出现了不存在的子命令:{sub}")
        have = set(re.findall(r"--[a-z][a-z-]*", rest.split("`")[0] if "`" in rest else rest))
        # 命令行出现在表格 / 行内代码里时,参数列表可能被反引号截断,所以只检查「出现的参数都存在」
        for fl in have:
            assert fl in flags_of(subs[sub]), f"`agent_gate {sub}` 没有参数 {fl}:{m.group(0)[:120]}"
        n_cmds += 1
    assert n_cmds >= 15, n_cmds

    # 4) § 引用都能找到标题;WP 引用都存在
    heads = set(re.findall(r"^#{2,3} (\d+(?:\.\d+)?)[. ]", doc, flags=re.M))
    for ref in set(re.findall(r"§(\d+(?:\.\d+)?)", doc)):
        assert ref in heads, f"§{ref} 找不到对应标题"
    wps = set(re.findall(r"^### (WP\d)", doc, flags=re.M))
    for ref in set(re.findall(r"\bWP\d\b", doc)):
        assert ref in wps, f"{ref} 找不到对应标题"

    # 5) 代码块都配对
    opened = None                                                # 只认「行首的围栏」;行内的反引号不算
    for no, line in enumerate(doc.splitlines(), 1):
        m = re.match(r"^\s*(`{3,})(.*)$", line)
        if not m:
            assert "```" not in line, f"第 {no} 行出现行内的三个反引号,换成文字描述:{line[:60]}"
            continue
        if opened is None:
            opened = (no, m.group(1))
        else:
            assert m.group(1) == opened[1] and not m.group(2).strip(), f"第 {no} 行的围栏和第 {opened[0]} 行对不上"
            opened = None
    assert opened is None, f"第 {opened[0]} 行的代码块没有结束"

    # 6) 版本号和测试总数
    assert tr["claude"] in doc and tr["mcode"] in doc and str(tr["total"]) in doc


# ====================================================================== 源码文本版 + 压缩包
LANG = {".py": "python", ".json": "json", ".md": "markdown", ".yaml": "yaml", ".yml": "yaml", ".txt": "text"}


def fence_for(content: str) -> str:
    runs = re.findall(r"`+", content)
    return "`" * max(3, (max(map(len, runs)) + 1) if runs else 3)


RESTORE_PY = '''\
"""从这份 md 还原源码文件。用法:python restore_from_md.py <这份md的路径> <输出目录>
按文件清单里的 SHA-256 逐个校验;全部一致才算成功。文件一律用 LF 换行写出。"""
import hashlib, re, sys
from pathlib import Path

md = Path(sys.argv[1]).read_text(encoding="utf-8").split("\\n")
out = Path(sys.argv[2])
want = {m.group(1): m.group(2) for l in md if (m := re.match(r"^\\| `([^`]+)` \\| \\d+ \\| ([0-9a-f]{64}) \\|$", l))}
got, i = {}, 0
while i < len(md):
    h = re.match(r"^### `([^`]+)`$", md[i])
    if h:
        j = i + 1
        while not re.match(r"^`{3,}\\w*$", md[j]):
            j += 1
        fence = re.match(r"^(`{3,})", md[j]).group(1)
        k = j + 1
        while md[k] != fence:
            k += 1
        got[h.group(1)] = "\\n".join(md[j + 1:k]) + "\\n"
        i = k
    i += 1
bad = 0
for rel, text in got.items():
    data = text.encode("utf-8")
    ok = hashlib.sha256(data).hexdigest() == want.get(rel)
    bad += not ok
    p = out / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    print(("OK       " if ok else "MISMATCH ") + rel)
missing = set(want) - set(got)
print(f"共 {len(got)} 个文件;不一致 {bad};清单里有但没找到 {len(missing)}")
sys.exit(1 if bad or missing else 0)
'''


def gen_source_md(tr: dict[str, Any]) -> str:
    files = kit_files()
    for rel in files:
        raw = (KIT / rel).read_bytes()
        assert b"\r" not in raw and raw.endswith(b"\n"), f"{rel}: 必须是 LF 换行且以换行结尾"
    parts = [
        "# agent_gate 参考实现源码（文本版）\n",
        "> 这份文件是 `agent_gate_kit.zip` 里全部源码的文本版，内容逐字节相同。**有压缩包就用压缩包**；"
        "只能传文本时，用下面的脚本还原。\n",
        f"- 对应设计文档：《{DOC_NAME[:-3]}》",
        f"- 验证环境：Claude Code {tr['claude']}、MiniMax Code {tr['mcode']}、Python {tr['python']}；{tr['total']} 个测试全过",
        "- 文件一律是 UTF-8、LF 换行。在 Windows 上编辑后保存成 CRLF 不影响运行，但会和下面的 SHA-256 对不上\n",
        "## 如何还原成文件\n",
        "1. 把这份 md 保存到本地（例如 `D:\\work\\src.md`），保持 UTF-8。",
        "2. 把下面的脚本存成 `restore_from_md.py`。",
        "3. 运行：",
        "",
        "```powershell",
        r"python restore_from_md.py D:\work\src.md D:\work\agent_gate_kit",
        "```",
        "",
        "脚本会逐个文件校验 SHA-256，最后一行是 `共 N 个文件;不一致 0;清单里有但没找到 0` 才算成功。",
        "补丁文件 `agent_gate_llm_seam.patch` 的全文在设计文档的附录 A，不在这里。\n",
        "```python", RESTORE_PY.rstrip("\n"), "```\n",
        "## 文件清单\n",
        "| 文件 | 行数 | SHA-256 |", "|---|---|---|",
    ]
    for rel in files:
        raw = (KIT / rel).read_bytes()
        parts.append(f"| `{rel.as_posix()}` | {len(raw.decode('utf-8').splitlines())} | {hashlib.sha256(raw).hexdigest()} |")
    parts.append("\n## 源码\n")
    for rel in files:
        text = read(KIT / rel)
        fence = fence_for(text)
        lang = LANG.get(rel.suffix, "text")
        parts += [f"### `{rel.as_posix()}`\n", f"{fence}{lang}", text.rstrip("\n"), fence, ""]
    return "\n".join(parts) + "\n"


README_ZIP = """# agent_gate_kit

让 Claude Code / MiniMax Code 直接驱动 `auto-video-editor` 的参考实现。
完整设计和执行步骤见《{doc}》。

## 里面有什么

| 路径 | 是什么 |
|---|---|
| `agent_gate/` | 新增的包。**复制到仓库根目录** |
| `agent_gate_llm_seam.patch` | 给仓库 2 个文件打的补丁（{patch_stat}） |
| `requirements-agent-gate.txt` | 本方案新增的 2 个依赖，精确版本 |
| `tests/`、`fixtures/` | 自动化测试和玩具图（{total} 个测试） |

## 最短用法（PowerShell；变量的定义见设计文档 §11）

```powershell
& $PY -m pip install -r "$KIT\\requirements-agent-gate.txt"
Copy-Item -Recurse -Force "$KIT\\agent_gate" $REPO
Set-Location $REPO
git apply --check "$KIT\\agent_gate_llm_seam.patch"
git apply "$KIT\\agent_gate_llm_seam.patch"
& $PY -m agent_gate --help
```

跑测试（在 `$KIT` 里）：`& $PY -m pytest tests -q -p no:cacheprovider`。没装 `claude` 或 `mcode` 的测试会自动跳过；需要 `ffmpeg` 在 `PATH` 里。
"""


def build_zip(g: dict[str, str], tr: dict[str, Any]) -> list[str]:
    zpath = OUT / ZIP_NAME
    if zpath.exists():
        zpath.unlink()
    entries: list[tuple[str, bytes]] = []
    for rel in kit_files():
        entries.append((rel.as_posix(), (KIT / rel).read_bytes()))
    entries.append((PATCH_NAME, PATCH.read_bytes()))
    entries.append(("requirements-agent-gate.txt", b"mcp==1.26.0\njsonschema==4.26.0\n"))
    entries.append(("README.md", README_ZIP.format(doc=DOC_NAME[:-3], patch_stat=g["PATCH_STAT"],
                                                  total=tr["total"]).encode("utf-8")))
    entries.sort(key=lambda e: e[0])
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in entries:
            zi = zipfile.ZipInfo(name, date_time=(2026, 10, 18, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            z.writestr(zi, data)
    return [n for n, _ in entries]


# ====================================================================== main
def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    tr = load_testrun()
    g: dict[str, str] = {}
    g.update(gen_patch())
    g["CONSTANTS_TABLE"] = gen_constants_table()
    g.update(gen_cli())
    g["MCP_TOOLS_TABLE"] = gen_mcp_tools()
    g.update(gen_configs())
    g.update(gen_file_table())
    g.update(gen_tests(tr))
    g.update(gen_samples())
    g.update(gen_checks())

    raw = "\n\n".join(read(PARTS / f"p{i}.md") for i in (1, 2, 3, 4))
    doc = substitute(raw, g)
    doc = re.sub(r"\n{3,}", "\n\n", doc).strip("\n") + "\n"
    check_doc(doc, tr)

    (OUT / DOC_NAME).write_text(doc, encoding="utf-8")
    src = gen_source_md(tr)
    (OUT / SRC_NAME).write_text(src, encoding="utf-8")
    shutil.copyfile(PATCH, OUT / PATCH_NAME)
    names = build_zip(g, tr)

    report = {
        "doc": str(OUT / DOC_NAME), "doc_lines": len(doc.splitlines()), "doc_bytes": len(doc.encode("utf-8")),
        "src": str(OUT / SRC_NAME), "src_lines": len(src.splitlines()), "src_bytes": len(src.encode("utf-8")),
        "zip": str(OUT / ZIP_NAME), "zip_bytes": (OUT / ZIP_NAME).stat().st_size, "zip_entries": len(names),
        "patch_stat": g["PATCH_STAT"], "pkg_lines": g["PKG_LINES"], "tests": tr["total"],
        "claude": tr["claude"], "mcode": tr["mcode"],
    }
    (OUT / "build_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
