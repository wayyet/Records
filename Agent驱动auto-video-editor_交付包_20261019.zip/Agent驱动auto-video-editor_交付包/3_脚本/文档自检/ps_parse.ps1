param([string]$Dir)
$bad = 0; $n = 0
Get-ChildItem -LiteralPath $Dir -Filter '*_powershell.txt' | Sort-Object Name | ForEach-Object {
    $n++
    $text = [System.IO.File]::ReadAllText($_.FullName, [System.Text.Encoding]::UTF8)
    $tokens = $null; $errs = $null
    [void][System.Management.Automation.Language.Parser]::ParseInput($text, [ref]$tokens, [ref]$errs)
    if ($errs.Count -gt 0) {
        $bad++
        Write-Output ("解析失败: " + $_.Name)
        $errs | ForEach-Object { Write-Output ("   行{0} 列{1}: {2}" -f $_.Extent.StartLineNumber, $_.Extent.StartColumnNumber, $_.Message) }
    }
}
Write-Output ("PowerShell 代码块 {0} 个,解析失败 {1} 个" -f $n, $bad)
