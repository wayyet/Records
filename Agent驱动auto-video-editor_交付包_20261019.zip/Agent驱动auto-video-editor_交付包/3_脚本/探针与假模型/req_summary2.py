import json, sys
rows = [json.loads(l) for l in open(sys.argv[1], encoding="utf-8")]
marker = sys.argv[2] if len(sys.argv) > 2 else "MARKER"
full = len(sys.argv) > 3 and sys.argv[3] == "full"
def tname(t):
    return t.get("name") or (t.get("function") or {}).get("name")
for r in rows:
    b = r.get("body") or {}
    if "messages" not in b:
        print("seq", r.get("seq"), r.get("path"), r.get("kind")); continue
    names = [tname(t) for t in b.get("tools", []) or []]
    txt = json.dumps(b.get("messages"), ensure_ascii=False) + json.dumps(b.get("system"), ensure_ascii=False)
    msgs = b["messages"]
    roles = [m.get("role") for m in msgs]
    print(f"seq {r['seq']} proto={r.get('proto')} main={r.get('main')} model={b.get('model')} stream={b.get('stream')} n_msgs={len(msgs)} roles={roles[:6]}{'...' if len(roles)>6 else ''}")
    print(f"   tools({len(names)}): {names if full or len(names)<=14 else names[:14]+['...']}")
    print(f"   marker_in_request={marker in txt}  total_chars={len(txt)}")
    keys = sorted(k for k in b.keys() if k not in ("messages", "tools"))
    print("   other keys:", keys)
