"""E2/E7: LangGraph 1.2.9 实验 (沙箱, 玩具图, 不碰仓库代码)。
E2: interrupt() 被 `except Exception` 吞掉
E7a: SqliteSaver 跨进程 resume (同步 API)
E7b: SqliteSaver + 异步 API (aget_state/ainvoke) 是否可用
E7c: 两个并行 interrupt 的 dict resume
"""
import asyncio, json, sqlite3, subprocess, sys, tempfile, os
from pathlib import Path
from typing import TypedDict, Annotated
import operator
from langgraph.graph import StateGraph, START, END
from langgraph.types import interrupt, Command
from langgraph.checkpoint.sqlite import SqliteSaver
import importlib.metadata as md

print("langgraph", md.version("langgraph"), "| checkpoint-sqlite", md.version("langgraph-checkpoint-sqlite"))

class S(TypedDict, total=False):
    log: Annotated[list, operator.add]

# ---------------- E2 ----------------
def swallow_node(state):
    try:
        v = interrupt({"checkpoint": "X"})      # 与仓库 11 处 `except Exception` 相同写法
    except Exception as e:                      # noqa: BLE001
        return {"log": [f"swallowed:{type(e).__name__}"]}
    return {"log": [f"resumed:{v}"]}

g = StateGraph(S); g.add_node("n", swallow_node); g.add_edge(START, "n"); g.add_edge("n", END)
from langgraph.checkpoint.memory import InMemorySaver
app = g.compile(checkpointer=InMemorySaver())
cfg = {"configurable": {"thread_id": "e2"}}
out = app.invoke({"log": []}, cfg)
print("E2 result:", out, "| interrupts seen by graph:", [i.value for i in app.get_state(cfg).interrupts])
from langgraph.errors import GraphInterrupt, GraphBubbleUp
print("E2 mro:", [c.__name__ for c in GraphInterrupt.__mro__])

# ---------------- E7a/b/c: 跨进程 ----------------
tmp = Path(tempfile.mkdtemp(prefix="e7_"))
db = tmp / "t1.sqlite"
child = r'''
import sys, json, sqlite3, asyncio, operator
from typing import TypedDict, Annotated
from langgraph.graph import StateGraph, START, END
from langgraph.types import interrupt, Command
from langgraph.checkpoint.sqlite import SqliteSaver
class S(TypedDict, total=False):
    log: Annotated[list, operator.add]
def a(state):
    interrupt({"checkpoint": "②", "step": 12, "instructions": "add bgm"})
    return {"log": ["a_done"]}
def b(state):
    interrupt({"checkpoint": "③", "step": 16, "instructions": "check layout"})
    return {"log": ["b_done"]}
def fin(state):
    return {"log": ["fin"]}
g = StateGraph(S)
g.add_node("a", a); g.add_node("b", b); g.add_node("fin", fin)
g.add_edge(START, "a"); g.add_edge(START, "b"); g.add_edge("a", "fin"); g.add_edge("b", "fin"); g.add_edge("fin", END)
db = sys.argv[1]; mode = sys.argv[2]
app = g.compile(checkpointer=SqliteSaver(sqlite3.connect(db, check_same_thread=False)))
cfg = {"configurable": {"thread_id": "job1"}}
if mode == "start":
    out = app.invoke({"log": []}, cfg)
    snap = app.get_state(cfg)
    print(json.dumps({"keys": sorted(out.keys()), "n_interrupts": len(snap.interrupts),
                      "payloads": [i.value for i in snap.interrupts], "next": list(snap.next)}, ensure_ascii=False))
elif mode == "resume_sync":
    snap = app.get_state(cfg)
    rm = {i.id: True for i in snap.interrupts}
    out = app.invoke(Command(resume=rm), cfg)
    print(json.dumps({"final_log": out.get("log"), "left": len(app.get_state(cfg).interrupts)}, ensure_ascii=False))
elif mode == "resume_single_value":
    # 两个挂起时直接传标量(不是 dict)
    try:
        out = app.invoke(Command(resume=True), cfg)
        print(json.dumps({"ok": True, "log": out.get("log")}))
    except Exception as e:
        print(json.dumps({"ok": False, "err": type(e).__name__ + ": " + str(e)[:200]}))
elif mode == "async_probe":
    async def go():
        try:
            snap = await app.aget_state(cfg)
            print(json.dumps({"aget_state_ok": True, "n": len(snap.interrupts)}))
        except Exception as e:
            print(json.dumps({"aget_state_ok": False, "err": type(e).__name__ + ": " + str(e)[:160]}))
        try:
            snap = app.get_state(cfg)
            rm = {i.id: True for i in snap.interrupts}
            out = await app.ainvoke(Command(resume=rm), cfg)
            print(json.dumps({"ainvoke_ok": True, "log": out.get("log")}))
        except Exception as e:
            print(json.dumps({"ainvoke_ok": False, "err": type(e).__name__ + ": " + str(e)[:160]}))
    asyncio.run(go())
'''
cp = tmp / "child.py"; cp.write_text(child, encoding="utf-8")
def run(mode, dbp=db):
    r = subprocess.run([sys.executable, str(cp), str(dbp), mode], capture_output=True, text=True, timeout=120)
    return r.stdout.strip() or r.stderr.strip()[-400:]
print("E7a start      (proc1):", run("start"))
print("E7c single val (proc2):", run("resume_single_value"))
print("E7a resume dict(proc3):", run("resume_sync"))
# async probe on a fresh db
db2 = tmp / "t2.sqlite"
print("E7b start      (proc1):", run("start", db2))
print("E7b async probe(proc2):", run("async_probe", db2))
print("db file:", db.name, db.stat().st_size, "bytes")
