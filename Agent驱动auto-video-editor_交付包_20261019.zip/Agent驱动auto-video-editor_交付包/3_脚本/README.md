# 3_脚本：说明

这些脚本是在 Linux 沙箱里写的。**路径写死在沙箱里**（例如 `/tmp/claude-0/...`），在你的机器上不能直接运行。
它们是过程记录。要复用，先改文件顶部的路径常量。

| 目录 | 作用 | 入口 |
|---|---|---|
| `文档构建/` | 从真实代码、测试结果、真实命令输出生成主文档和源码文本版，同时生成压缩包和补丁，并做一致性断言（不一致就构建失败） | 先 `mk_testrun.py`（读测试结果），再 `build.py` |
| `文档自检/` | 把文档的代码块按语言拆出来；检查 Mermaid 图、JSON/YAML、`claude`/`mcode` 命令行参数、PowerShell 语法 | `extract.py` 先跑，其余读它的输出 |
| `探针与假模型/` | 本地假模型（按剧本回答，同时支持 Anthropic 和 OpenAI 两种协议）；在隔离环境里跑真实 `claude` / `mcode` 的脚本 | `mockllm2.py`、`cc.sh`、`mm.sh` |
| `补丁等价测试/` | 用替身模块对比“补丁前”和“补丁后”的行为 | `drive_sim.py` |
| `实验/` | 验证 LangGraph 行为的实验（只用玩具图，不碰仓库代码） | `exp_langgraph.py` |

## 各目录里有什么

**`文档构建/`**
- `build.py`：构建脚本。
- `mk_testrun.py`：读 `test_run_final2.xml`，写出 `testrun.json`（共 89 个，各测试文件的个数和用时）。
- `testrun.json`、`checks.json`：构建时读入的数据。`checks.json` 是主文档附录 C 自检表的内容。
- `parts/p1.md` … `p4.md`：主文档的源文本，里面有 `{{占位符}}`，构建时用真实数据填。
- `samples/`：文档里样例输出的原始数据（真实运行命令行得到的任务文件、状态、事件）。

**`文档自检/`**
- `extract.py`：把文档的代码块按语言拆出来。
- `mermaid_check.py`：用 mermaid 官方解析器，在无头 Chromium 里解析并渲染每张图。
- `mermaid_png.py`：把图渲染成 PNG（`1_文档/图预览/` 里的图就是这样出的）。
- `data_check.py`：检查 JSON、YAML、事件日志能否解析。
- `flags_check.py`：检查文档里每条 `claude` / `mcode` 命令行的参数，都能在真实 `--help` 里找到。
- `ps_parse.ps1`：用 PowerShell 自带的解析器检查语法，不执行。
- `help/`：真实的 `claude --help`、`mcode --help` 等输出（`flags_check.py` 的对照依据）。

**`探针与假模型/`**
- `mockllm2.py`：假模型服务。`mockllm.py` 是早期版本（只有固定步骤，没有“策略”模式）。
- `cc.sh`、`mm.sh`：起假模型，在隔离环境里跑真实 `claude` / `mcode`，收日志。
- `剧本/`：`script_*.json`，假模型按它回答。
- 其他：`race_probe.py`（启动竞态）、`slow_mcp.py`、`slow_start.sh`（慢启动的 MCP 服务）、`guard_hook.py`、`deny_settings.json`、`hook_settings.json`（权限和钩子试验）、`first_req_tools.py`、`req_summary.py`、`req_summary2.py`、`show_results.py`、`show_tools_oai.py`（读请求日志）。
- 原始请求日志（`log_*.jsonl`，约 17 MB）没有放进来。

**`补丁等价测试/`**
- `orig/`、`new/`：2 个被补丁修改的文件，补丁前和补丁后。
- `sim_orig/`、`sim_new/`：替身包（用仓库真实的 `vlm_client.py`、`bgm_selector.py` + 替身提示词）。
- `drive_sim.py`：在替身包上跑 3 个场景，输出 JSON。结果在 `out_orig.json`、`out_new.json`。
- 用法：`python3 -I drive_sim.py <sim 目录>`。
