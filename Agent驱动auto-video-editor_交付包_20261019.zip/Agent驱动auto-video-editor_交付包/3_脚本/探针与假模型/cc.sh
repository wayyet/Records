#!/usr/bin/env bash
# 用法: cc.sh NAME PORT SCRIPT_JSON PROJECT_DIR [claude 参数...]
# 起假模型 → 在隔离环境里跑真实 claude → 收日志 → 关假模型
S=/tmp/claude-0/-home-claude/8d8266ac-1614-53a6-a397-b6195d29cd20/scratchpad
NAME=$1; PORT=$2; SCRIPT=$3; PROJ=$4; shift 4
LOG=$S/harness/log_$NAME.jsonl; rm -f "$LOG"
python3 $S/harness/mockllm2.py "$PORT" "$SCRIPT" "$LOG" > $S/harness/mock_$NAME.out 2>&1 &
MPID=$!
sleep 1
cd "$PROJ" || exit 9
env -i PATH="/opt/node22/bin:/usr/local/bin:/usr/bin:/bin" HOME=$S/cc-home CLAUDE_CONFIG_DIR=$S/cc-home/.claude \
  ANTHROPIC_BASE_URL=http://127.0.0.1:$PORT ANTHROPIC_API_KEY=sk-ant-api03-fake-local-mock-key \
  ANTHROPIC_DEFAULT_HAIKU_MODEL=mock-haiku ANTHROPIC_SMALL_FAST_MODEL=mock-haiku \
  CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1 DISABLE_TELEMETRY=1 DISABLE_AUTOUPDATER=1 DISABLE_ERROR_REPORTING=1 \
  NO_PROXY=127.0.0.1,localhost no_proxy=127.0.0.1,localhost $EXTRA_ENV \
  timeout 300 claude "$@" < /dev/null > $S/out/$NAME.json 2> $S/out/$NAME.err
echo "claude exit=$?"
kill $MPID 2>/dev/null
wait $MPID 2>/dev/null
echo "mock log lines: $(wc -l < "$LOG")"
