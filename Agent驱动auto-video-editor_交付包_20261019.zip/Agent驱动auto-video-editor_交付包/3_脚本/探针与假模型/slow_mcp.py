import time
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("slow")


@mcp.tool()
def nap(seconds: float) -> str:
    """睡 seconds 秒后返回(测试 MCP 工具调用超时)。"""
    time.sleep(seconds)
    return f"slept {seconds}"


if __name__ == "__main__":
    mcp.run(transport="stdio")
