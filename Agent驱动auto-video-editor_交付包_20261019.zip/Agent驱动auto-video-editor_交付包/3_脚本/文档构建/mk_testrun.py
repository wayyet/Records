import json, sys, xml.etree.ElementTree as ET
from collections import Counter
S = sys.argv[1]
root = ET.parse(S + "/test_run_final2.xml").getroot()
ts = root.find("testsuite")
per = Counter()
for tc in ts.iter("testcase"):
    per[tc.get("classname").split(".")[-1]] += 1
out = {
    "total": int(ts.get("tests")),
    "per_file": dict(per),
    "failures": int(ts.get("failures")),
    "errors": int(ts.get("errors")),
    "skipped": int(ts.get("skipped")),
    "time_s": round(float(ts.get("time"))),
    "claude": "2.1.302",
    "mcode": "0.6.9",
    "python": "3.13.16",
}
assert sum(per.values()) == out["total"]
json.dump(out, open(S + "/doc/testrun.json", "w"), ensure_ascii=False, indent=1)
print(json.dumps(out, ensure_ascii=False))
