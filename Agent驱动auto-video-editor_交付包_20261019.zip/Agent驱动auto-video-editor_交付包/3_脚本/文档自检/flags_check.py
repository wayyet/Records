import re, sys
from pathlib import Path
doc = Path(sys.argv[1]).read_text(encoding="utf-8").splitlines()
H = Path("help")
claude_help = (H / "claude_help.txt").read_text(encoding="utf-8")
mcode_texts = {k: (H / f"mcode_{k}_help.txt").read_text(encoding="utf-8") for k in ("exec", "provider_add", "provider_remove", "provider_list", "login", "provider")}
mcode_top = (H / "mcode_help.txt").read_text(encoding="utf-8")
claude_flags = set(re.findall(r"--[a-z][a-z-]*", claude_help))
HIDDEN_OK = {"--max-turns"}   # claude --help 没列出,但 2.1.302 接受(实测:未知参数会立刻报错,它不会)
mcode_all = set(re.findall(r"--[a-z][a-z-]*", mcode_top + "".join(mcode_texts.values())))
rows, bad = [], 0
for no, line in enumerate(doc, 1):
    # 只看"命令行"出现的地方:行里含 claude -p / claude mcp / mcode exec / mcode provider / mcode --config
    m_c = re.search(r"\bclaude(?:\.cmd)? (-p|mcp|--version)", line)
    m_m = re.search(r"\bmcode(?:\.cmd)? (exec|provider|login|--config|--version)", line)
    if not (m_c or m_m):
        continue
    # 沙箱路径之类不会出现;只取形如 --xxx 的参数
    seg = line
    if m_c:
        seg_after = line[m_c.start():]
        # 只取到下一个 mcode 出现之前
        seg_after = re.split(r"\bmcode\b", seg_after)[0]
        flags = set(re.findall(r"(?<![\w-])--[a-z][a-z-]*", seg_after))
        miss = sorted(f for f in flags if f not in claude_flags and f not in HIDDEN_OK)
        rows.append((no, "claude", sorted(flags), miss))
        bad += bool(miss)
    if m_m:
        seg_after = line[m_m.start():]
        seg_after = re.split(r"\bclaude\b", seg_after)[0]
        flags = set(re.findall(r"(?<![\w-])--[a-z][a-z-]*", seg_after))
        miss = sorted(f for f in flags if f not in mcode_all)
        rows.append((no, "mcode", sorted(flags), miss))
        bad += bool(miss)
for no, who, flags, miss in rows:
    print(f"行{no:5d} {who:6s} 参数 {len(flags):2d} 个 {'缺失:' + ','.join(miss) if miss else 'OK'}")
print("命令行共", len(rows), "处;有缺失参数的", bad, "处")
