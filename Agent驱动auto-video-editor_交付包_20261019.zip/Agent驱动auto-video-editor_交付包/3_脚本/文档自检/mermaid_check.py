import json, sys
from pathlib import Path
from playwright.sync_api import sync_playwright

S = Path(sys.argv[1])
blocks = sorted((S / "doc/chk/blocks").glob("*_mermaid.txt"))
js = (S / "mmd/node_modules/mermaid/dist/mermaid.min.js").read_text(encoding="utf-8")
html = "<!doctype html><html><body><div id='out'></div></body></html>"
res = []
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page()
    pg.set_content(html)
    pg.add_script_tag(content=js)
    pg.evaluate("() => mermaid.initialize({startOnLoad:false, securityLevel:'strict'})")
    for f in blocks:
        text = f.read_text(encoding="utf-8")
        r = pg.evaluate("""async (t) => {
            try {
              const ok = await mermaid.parse(t);
              const out = await mermaid.render('g' + Math.floor(Math.random()*1e9), t);
              return {ok: true, type: ok.diagramType, svg_len: out.svg.length, has_error_text: /Syntax error/i.test(out.svg)};
            } catch (e) { return {ok: false, err: String(e && e.message || e)}; }
        }""", text)
        r["file"] = f.name
        res.append(r)
    b.close()
for r in res:
    print(json.dumps(r, ensure_ascii=False))
print("全部通过" if all(r["ok"] and not r.get("has_error_text") for r in res) else "有失败")
