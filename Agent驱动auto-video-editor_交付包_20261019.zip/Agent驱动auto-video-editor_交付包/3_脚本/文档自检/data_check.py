import json, sys
from pathlib import Path
import yaml
B = Path("blocks")
idx = {i["n"]: i for i in json.loads((B / "index.json").read_text(encoding="utf-8"))}
ok = True
for f in sorted(B.glob("*_json.txt")):
    try:
        v = json.loads(f.read_text(encoding="utf-8"))
        print("JSON  OK ", f.name, "行", idx[int(f.name[:3])]["line"], type(v).__name__, list(v)[:6] if isinstance(v, dict) else "")
    except Exception as e:
        ok = False; print("JSON  失败", f.name, e)
for f in sorted(B.glob("*_yaml.txt")):
    try:
        v = yaml.safe_load(f.read_text(encoding="utf-8"))
        print("YAML  OK ", f.name, list(v))
        assert set(v) == {"agents", "askUser", "skills"}, set(v)
    except Exception as e:
        ok = False; print("YAML  失败", f.name, e)
# text 块里的 JSON 行(事件样例)
for f in sorted(B.glob("*_text.txt")):
    txt = f.read_text(encoding="utf-8")
    lines = [l for l in txt.splitlines() if l.strip()]
    if lines and all(l.startswith("{") for l in lines):
        evs = [json.loads(l) for l in lines]
        print("事件行 OK", f.name, len(evs), "行;事件名:", [e["event"] for e in evs])
print("全部通过" if ok else "有失败")
