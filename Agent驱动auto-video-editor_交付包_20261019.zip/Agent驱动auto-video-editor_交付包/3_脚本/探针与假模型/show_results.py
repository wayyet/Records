"""打印假模型日志里第 N 个请求中所有 tool_result 的文本(截断)和 is_error。"""
import json, sys
rows = [json.loads(l) for l in open(sys.argv[1], encoding="utf-8")]
idx = int(sys.argv[2]) if len(sys.argv) > 2 else -1
body = rows[idx]["body"]
id2name = {}
for m in body["messages"]:
    c = m["content"]
    if isinstance(c, list):
        for x in c:
            if x.get("type") == "tool_use":
                id2name[x["id"]] = x["name"]
for m in body["messages"]:
    c = m["content"]
    if isinstance(c, list):
        for x in c:
            if x.get("type") == "tool_result":
                cc = x.get("content")
                if isinstance(cc, list):
                    cc = "".join(y.get("text", "") for y in cc if isinstance(y, dict) and y.get("type") == "text")
                print(f"[{id2name.get(x.get('tool_use_id'))}] is_error={x.get('is_error')} :: {str(cc)[:int(sys.argv[3]) if len(sys.argv)>3 else 260]!r}")
