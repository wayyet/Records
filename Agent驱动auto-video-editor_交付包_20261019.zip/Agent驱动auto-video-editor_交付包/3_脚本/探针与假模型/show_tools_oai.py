import json, sys
rows = [json.loads(l) for l in open(sys.argv[1], encoding="utf-8")]
main = [r for r in rows if r.get("main")]
b = main[-1]["body"]
n = int(sys.argv[2]) if len(sys.argv) > 2 else 200
id2name = {}
for m in b["messages"]:
    for tc in m.get("tool_calls") or []:
        id2name[tc["id"]] = tc["function"]["name"]
for m in b["messages"]:
    if m.get("role") == "tool":
        c = m.get("content")
        if isinstance(c, list):
            c = "".join(x.get("text", "") for x in c if isinstance(x, dict))
        print(f"[{id2name.get(m.get('tool_call_id'))}] {str(c)[:n]!r}")
