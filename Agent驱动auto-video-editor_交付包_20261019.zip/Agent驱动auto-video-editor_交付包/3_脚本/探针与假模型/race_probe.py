"""探针:MCP 服务启动慢(4 秒)时,claude 2.1.x 首轮请求里有几个 MCP 工具?三种启动方式对比。"""
import json, os, sys, tempfile
from pathlib import Path
ROOT = Path(os.environ["REF_IMPL"])
sys.path[:0] = [str(ROOT), str(ROOT / "tests")]
from support import CLAUDE_BIN, MockServer, claude_env, tool_names
from agent_gate.cli_client import run_process
from agent_gate.scaffold import init_project

STATUS = {"main_models": ["mock-main"], "default_text": "结束", "anthropic": [
    {"text": "看状态", "tools": [{"name_regex": "run_status$", "input": {"thread_id": "x1"}}]}, {"text": "结束"}]}

def run(label, extra_flags, env_wait):
    tmp = Path(tempfile.mkdtemp(prefix="race_"))
    ops = tmp / "ops"
    init_project(project_dir=ops, repo_root=ROOT / "fixtures", outputs_root=tmp / "out",
                 graph_factory="toy_graph:build_graph", python=sys.executable)
    p = ops / ".mcp.json"
    cfg = json.loads(p.read_text(encoding="utf-8"))
    s = cfg["mcpServers"]["video-agent"]
    s["args"] = ["-c", "import time; time.sleep(4); from agent_gate.mcp_server import main; main()"] + s["args"][2:]
    p.write_text(json.dumps(cfg), encoding="utf-8")
    srv = MockServer(tmp, STATUS)
    try:
        env = {k: v for k, v in os.environ.items() if k in ("PATH", "SYSTEMROOT", "TEMP", "TMP", "LANG", "LC_ALL")}
        env.update(claude_env(tmp, srv.port)); env["PYTHONUTF8"] = "1"
        if env_wait: env["CLAUDE_CODE_MCP_STARTUP_WAIT_MS"] = env_wait
        cmd = [CLAUDE_BIN, "-p", "--output-format", "json", "--model", "mock-main", "--permission-mode", "dontAsk",
               "--allowedTools", "mcp__video-agent__*", "--max-turns", "5", "--no-session-persistence"] + extra_flags
        cmd = [c.replace("{PROJ}", str(ops)) for c in cmd]
        run_process(cmd, "试", cwd=str(ops), env=env, timeout_s=90, label=label)
        reqs = srv.main_requests()
        counts = [len([n for n in tool_names(r["body"]) if n.startswith("mcp__")]) for r in reqs]
        print(f"{label:48s} 每个请求里的 MCP 工具数: {counts}")
    finally:
        srv.close()

run("A 自动加载 .mcp.json,不设等待变量", [], None)
run("B --mcp-config + --strict-mcp-config,不设等待变量", ["--tools", "", "--mcp-config", "{PROJ}/.mcp.json", "--strict-mcp-config"], None)
run("C 自动加载 .mcp.json,CLAUDE_CODE_MCP_STARTUP_WAIT_MS=30000", [], "30000")
run("D --tools '' 但仍自动加载 .mcp.json,不设等待变量", ["--tools", ""], None)
