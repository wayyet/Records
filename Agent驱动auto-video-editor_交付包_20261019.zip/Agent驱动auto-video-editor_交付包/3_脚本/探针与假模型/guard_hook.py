#!/usr/bin/env python3
"""PreToolUse 钩子:退出码 2 = 拒绝,stderr 的内容会回给模型。"""
import json
import re
import sys

ev = json.load(sys.stdin)
name = ev.get("tool_name", "")
inp = ev.get("tool_input", {}) or {}
text = json.dumps(inp, ensure_ascii=False)
if name.endswith("human_resume"):
    print("禁止:人工关卡只能由真人放行,Agent 不得调用 human_resume。", file=sys.stderr)
    sys.exit(2)
if name in ("Bash", "Read", "Write", "Edit") and re.search(r"\.sqlite|\.result\.json|/gate/", text):
    print("禁止:不得直接读写检查点库或闸门结果文件。", file=sys.stderr)
    sys.exit(2)
sys.exit(0)
