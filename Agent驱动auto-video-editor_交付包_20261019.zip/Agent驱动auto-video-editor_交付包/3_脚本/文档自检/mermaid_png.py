import sys
from pathlib import Path
from playwright.sync_api import sync_playwright
S = Path(sys.argv[1])
js = (S / "mmd/node_modules/mermaid/dist/mermaid.min.js").read_text(encoding="utf-8")
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 1400, "height": 900}, device_scale_factor=1.3)
    pg.set_content("<!doctype html><html><body style='background:#fff;margin:12px'><div id='out'></div></body></html>")
    pg.add_script_tag(content=js)
    pg.evaluate("() => mermaid.initialize({startOnLoad:false, securityLevel:'strict', theme:'default'})")
    for f in sorted((S / "doc/chk/blocks").glob("*_mermaid.txt")):
        svg = pg.evaluate("async (t) => (await mermaid.render('x' + Math.floor(Math.random()*1e9), t)).svg", f.read_text(encoding="utf-8"))
        pg.evaluate("(s) => { document.getElementById('out').innerHTML = s; }", svg)
        el = pg.query_selector("#out svg")
        el.screenshot(path=str(S / "doc/chk/png" / (f.stem + ".png")))
    b.close()
print("ok")
