"""把文档里的代码块按语言拆出来,写到 chk/blocks/<序号>_<语言>.txt,并输出清单。"""
import json, re, sys
from pathlib import Path
doc_path, outdir = Path(sys.argv[1]), Path(sys.argv[2])
outdir.mkdir(parents=True, exist_ok=True)
for f in outdir.glob("*"):
    f.unlink()
lines = doc_path.read_text(encoding="utf-8").split("\n")
blocks, i = [], 0
while i < len(lines):
    m = re.match(r"^(\s*)(`{3,})(\S*)\s*$", lines[i])
    if m:
        fence, lang, start = m.group(2), m.group(3) or "text", i + 1
        j = i + 1
        while not re.match(rf"^\s*{fence}\s*$", lines[j]):
            j += 1
        blocks.append({"n": len(blocks) + 1, "lang": lang, "line": start, "end": j + 1, "text": "\n".join(lines[i + 1:j])})
        i = j
    i += 1
for b in blocks:
    (outdir / f"{b['n']:03d}_{b['lang']}.txt").write_text(b["text"] + "\n", encoding="utf-8")
(outdir / "index.json").write_text(json.dumps([{k: v for k, v in b.items() if k != "text"} for b in blocks], ensure_ascii=False, indent=1), encoding="utf-8")
from collections import Counter
print(Counter(b["lang"] for b in blocks), "共", len(blocks), "个代码块")
