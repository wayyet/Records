#!/usr/bin/env bash
sleep ${SLOW_S:-4}
exec /tmp/claude-0/-home-claude/ef20be9b-5c21-4f5c-91cd-cd7a7829a245/scratchpad/venv/bin/python -m agent_gate.mcp_server "$@"
