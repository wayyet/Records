#!/usr/bin/env python3
"""Local mock LLM server for plumbing tests (no real model, no network).

Speaks two protocols on 127.0.0.1:
  POST /v1/messages          Anthropic Messages (stream + non-stream)
  POST /v1/chat/completions  OpenAI Chat Completions (stream + non-stream)
Replies come from a JSON script. Every request is appended to a JSONL log.

Usage: python mockllm.py PORT SCRIPT.json LOG.jsonl
Script: {"main_models": ["mock-main"], "anthropic": [STEP...], "openai": [STEP...],
         "default_text": "ok"}
STEP : {"text": "..."} | {"tools": [{"name_regex": "...", "input": {...}}]}
       optional {"text": "...", "tools": [...]} for text + tool calls together.
Step index = number of assistant messages already in the request.
Only requests whose "model" is in main_models consume script steps; all other
requests (side queries) get default_text.
"""
import json, re, sys, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(sys.argv[1])
SCRIPT = json.load(open(sys.argv[2], encoding="utf-8"))
LOG = sys.argv[3]
LOCK = threading.Lock()
SEQ = [0]


def log(rec):
    with LOCK:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def tool_names(body, proto):
    out = []
    for t in body.get("tools") or []:
        if proto == "anthropic":
            out.append(t.get("name"))
        else:
            out.append((t.get("function") or {}).get("name"))
    return [n for n in out if n]


def pick_step(body, proto):
    key = "anthropic" if proto == "anthropic" else "openai"
    steps = SCRIPT.get(key) or []
    n_assistant = sum(1 for m in body.get("messages", []) if m.get("role") == "assistant")
    if body.get("model") not in SCRIPT.get("main_models", ["mock-main"]):
        return {"text": SCRIPT.get("default_text", "ok")}, n_assistant, False
    if n_assistant < len(steps):
        return steps[n_assistant], n_assistant, True
    return {"text": SCRIPT.get("default_text", "ok")}, n_assistant, True


def resolve_tools(step, body, proto):
    names = tool_names(body, proto)
    calls = []
    for spec in step.get("tools") or []:
        name = spec.get("name")
        if not name and spec.get("name_regex"):
            rx = re.compile(spec["name_regex"])
            hit = [n for n in names if rx.search(n)]
            name = hit[0] if hit else spec["name_regex"]
        calls.append((name, spec.get("input", {})))
    return calls


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):  # quiet
        pass

    def _send_json(self, code, obj):
        raw = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        log({"seq": self._seq(), "method": "GET", "path": self.path})
        self._send_json(200, {"data": [], "has_more": False})

    def _seq(self):
        with LOCK:
            SEQ[0] += 1
            return SEQ[0]

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n) if n else b""
        try:
            body = json.loads(raw.decode("utf-8")) if raw else {}
        except Exception:
            body = {"_raw": raw.decode("utf-8", "replace")}
        path = self.path.split("?")[0]
        seq = self._seq()
        hdr = {k.lower(): v for k, v in self.headers.items()
               if k.lower() in ("x-api-key", "authorization", "anthropic-beta", "anthropic-version", "user-agent")}
        if path == "/v1/messages":
            self._anthropic(seq, body, hdr)
        elif path.endswith("/chat/completions"):
            self._openai(seq, body, hdr)
        elif path == "/v1/messages/count_tokens":
            log({"seq": seq, "path": path, "kind": "count_tokens"})
            self._send_json(200, {"input_tokens": 10})
        else:
            log({"seq": seq, "path": path, "kind": "other", "body": body})
            self._send_json(200, {})

    # ---------------- Anthropic ----------------
    def _anthropic(self, seq, body, hdr):
        step, idx, is_main = pick_step(body, "anthropic")
        calls = resolve_tools(step, body, "anthropic")
        log({"seq": seq, "path": "/v1/messages", "proto": "anthropic", "main": is_main,
             "step_index": idx, "headers": hdr, "body": body, "reply": step})
        blocks = []
        if step.get("text"):
            blocks.append({"type": "text", "text": step["text"]})
        for i, (name, inp) in enumerate(calls):
            blocks.append({"type": "tool_use", "id": f"toolu_{seq}_{i}", "name": name, "input": inp})
        stop = "tool_use" if calls else "end_turn"
        model = body.get("model", "mock")
        if not body.get("stream"):
            self._send_json(200, {"id": f"msg_{seq}", "type": "message", "role": "assistant", "model": model,
                                  "content": blocks, "stop_reason": stop, "stop_sequence": None,
                                  "usage": {"input_tokens": 10, "output_tokens": 5}})
            return
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Transfer-Encoding", "chunked")
        self.end_headers()

        def ev(name, data):
            payload = f"event: {name}\ndata: {json.dumps(data)}\n\n".encode()
            self.wfile.write(f"{len(payload):x}\r\n".encode() + payload + b"\r\n")
            self.wfile.flush()

        ev("message_start", {"type": "message_start", "message": {
            "id": f"msg_{seq}", "type": "message", "role": "assistant", "model": model, "content": [],
            "stop_reason": None, "stop_sequence": None,
            "usage": {"input_tokens": 10, "output_tokens": 1}}})
        for i, b in enumerate(blocks):
            if b["type"] == "text":
                ev("content_block_start", {"type": "content_block_start", "index": i,
                                           "content_block": {"type": "text", "text": ""}})
                ev("content_block_delta", {"type": "content_block_delta", "index": i,
                                           "delta": {"type": "text_delta", "text": b["text"]}})
            else:
                ev("content_block_start", {"type": "content_block_start", "index": i,
                                           "content_block": {"type": "tool_use", "id": b["id"],
                                                             "name": b["name"], "input": {}}})
                ev("content_block_delta", {"type": "content_block_delta", "index": i,
                                           "delta": {"type": "input_json_delta",
                                                     "partial_json": json.dumps(b["input"])}})
            ev("content_block_stop", {"type": "content_block_stop", "index": i})
        ev("message_delta", {"type": "message_delta", "delta": {"stop_reason": stop, "stop_sequence": None},
                             "usage": {"output_tokens": 5}})
        ev("message_stop", {"type": "message_stop"})
        self.wfile.write(b"0\r\n\r\n")
        self.wfile.flush()

    # ---------------- OpenAI ----------------
    def _openai(self, seq, body, hdr):
        step, idx, is_main = pick_step(body, "openai")
        calls = resolve_tools(step, body, "openai")
        log({"seq": seq, "path": "/v1/chat/completions", "proto": "openai", "main": is_main,
             "step_index": idx, "headers": hdr, "body": body, "reply": step})
        model = body.get("model", "mock")
        msg = {"role": "assistant", "content": step.get("text") or None}
        tcs = []
        for i, (name, inp) in enumerate(calls):
            tcs.append({"index": i, "id": f"call_{seq}_{i}", "type": "function",
                        "function": {"name": name, "arguments": json.dumps(inp)}})
        finish = "tool_calls" if tcs else "stop"
        if not body.get("stream"):
            m = dict(msg)
            if tcs:
                m["tool_calls"] = [{k: v for k, v in t.items() if k != "index"} for t in tcs]
            self._send_json(200, {"id": f"chatcmpl-{seq}", "object": "chat.completion", "created": int(time.time()),
                                  "model": model, "choices": [{"index": 0, "message": m, "finish_reason": finish}],
                                  "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}})
            return
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Transfer-Encoding", "chunked")
        self.end_headers()

        def chunk(delta, fin=None, usage=None):
            obj = {"id": f"chatcmpl-{seq}", "object": "chat.completion.chunk", "created": int(time.time()),
                   "model": model, "choices": [{"index": 0, "delta": delta, "finish_reason": fin}]}
            if usage:
                obj["usage"] = usage
            payload = f"data: {json.dumps(obj)}\n\n".encode()
            self.wfile.write(f"{len(payload):x}\r\n".encode() + payload + b"\r\n")
            self.wfile.flush()

        chunk({"role": "assistant", "content": ""})
        if step.get("text"):
            chunk({"content": step["text"]})
        if tcs:
            chunk({"tool_calls": tcs})
        chunk({}, fin=finish)
        if (body.get("stream_options") or {}).get("include_usage"):
            obj = {"id": f"chatcmpl-{seq}", "object": "chat.completion.chunk", "created": int(time.time()),
                   "model": model, "choices": [],
                   "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}}
            payload = f"data: {json.dumps(obj)}\n\n".encode()
            self.wfile.write(f"{len(payload):x}\r\n".encode() + payload + b"\r\n")
        done = b"data: [DONE]\n\n"
        self.wfile.write(f"{len(done):x}\r\n".encode() + done + b"\r\n")
        self.wfile.write(b"0\r\n\r\n")
        self.wfile.flush()


class Srv(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


if __name__ == "__main__":
    Srv(("127.0.0.1", PORT), H).serve_forever()
