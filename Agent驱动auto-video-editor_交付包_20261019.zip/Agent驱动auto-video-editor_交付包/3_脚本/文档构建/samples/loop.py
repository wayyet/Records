import json, subprocess, sys, os
PY, OUT = sys.argv[1], sys.argv[2]
def cli(*a, inp=None):
    cp = subprocess.run([PY, "-m", "agent_gate", *a], capture_output=True, text=True, encoding="utf-8", stdin=subprocess.DEVNULL, timeout=120)
    return json.loads(cp.stdout) if cp.stdout.strip() else {}
def canned(p):
    if "美学评分" in p: return {"caption": "画面", "aes_score": 6.0}
    if "要保留的 clip id" in p: return {"keep_clip_ids": ["c1", "c3"]}
    if "20 字" in p: return "两个好镜头"
    if "总结" in p: return {"summary": "ok"}
    if "转场" in p: return {"transition": "fade"}
    return {"note": "?"}
for _ in range(30):
    r = cli("tasks", "--thread-id", "demo", "--outputs-root", OUT, "--wait-s", "20", "--limit", "5")
    if r.get("next_action") != "answer_tasks" and not r.get("tasks"):
        print(json.dumps({k: r[k] for k in r if k != "tasks"}, ensure_ascii=False, indent=2)); break
    for t in r["tasks"]:
        a = canned(t["user_prompt"])
        cli("submit", "--thread-id", "demo", "--outputs-root", OUT, "--task-id", t["task_id"], "--answer", a if isinstance(a, str) else json.dumps(a, ensure_ascii=False))
