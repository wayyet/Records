import json, sys
rows = [json.loads(l) for l in open(sys.argv[1], encoding="utf-8")]
marker = sys.argv[2] if len(sys.argv) > 2 else "MARKER"
for r in rows:
    if not r.get("main"):
        continue
    b = r["body"]
    names = [t["name"] for t in b.get("tools", [])]
    sysb = json.dumps(b.get("system"), ensure_ascii=False)
    msgs = json.dumps(b.get("messages"), ensure_ascii=False)
    print(f"seq {r['seq']}: tools={names} system_chars={len(sysb)} marker_in_system={marker in sysb} marker_in_messages={marker in msgs}")
    first = b["messages"][0]["content"]
    if isinstance(first, list):
        first = " | ".join((x.get("text", "") or "")[:70].replace("\n", " ") for x in first if x.get("type") == "text")
    print("   first user:", str(first)[:260])
    print("   output_config/format:", json.dumps(b.get("output_config") or b.get("response_format"), ensure_ascii=False)[:200])
