def render_prompt(group, name, lang="zh", **kw):
    return f"{group}/{name}"
