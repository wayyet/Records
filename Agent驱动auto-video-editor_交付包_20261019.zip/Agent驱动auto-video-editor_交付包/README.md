# 交付包：Agent 程序直接驱动 auto-video-editor

日期：2026-10-19

**一句话**：让 Claude Code 或 MiniMax Code 当“大模型”，直接驱动 `auto-video-editor`，不再接 LLM API。
仓库只改 2 个文件（+11 −5 行），再新增 1 个 `agent_gate/` 包。

## 先看哪个

1. `1_文档/Agent程序直接驱动auto-video-editor_设计与执行计划.md`：主文档。§1 是一页摘要，§11 是执行步骤。
2. `Agent程序直接驱动auto-video-editor_对话总结.md`：这次对话的总结。

## 目录

| 目录 | 内容 |
|---|---|
| `1_文档/` | 主文档；参考实现源码的文本版；4 张图的 PNG 预览 |
| `2_代码/` | `agent_gate_kit.zip`（参考实现 + 89 个测试 + 补丁）；同一份已解压在 `agent_gate_kit/` |
| `3_脚本/` | 文档构建、文档自检、探针、补丁等价测试、实验。说明见该目录的 `README.md` |
| `4_验证记录/` | 最终测试结果；过程中记下的已验证事实 |

## 最短用法（PowerShell）

先在主文档 §11 的「变量」里设好 `$REPO`、`$KIT`、`$PY`。
`$KIT` 指向本包里 `2_代码\agent_gate_kit` 的完整路径即可（已解压，不用再解压 zip）。
前提：已按主文档 WP0 建好 `$REPO\.venv`，并装好仓库自己的依赖。

```powershell
& $PY -m pip install -r "$KIT\requirements-agent-gate.txt"
Copy-Item -Recurse -Force "$KIT\agent_gate" $REPO
Set-Location $REPO
git apply --check "$KIT\agent_gate_llm_seam.patch"
git apply "$KIT\agent_gate_llm_seam.patch"
& $PY -m agent_gate --help
```

跑测试（在 `$KIT` 里；没装 `claude` 或 `mcode` 的测试会自动跳过；需要 `ffmpeg` 在 `PATH` 里）：

```powershell
Set-Location $KIT
$env:AGENT_GATE_MCODE_BIN = (Get-Command mcode).Source    # 没装 mcode 就跳过这一行
& $PY -m pytest tests -q -p no:cacheprovider
```

## 状态

- **已验证**（Linux 沙箱：真实 Claude Code 2.1.302 + 真实 MiniMax Code 0.6.9 + 本地假模型）：89 个测试全过。
- **没验证**：真实模型的答题质量；仓库**真实**的图（只用了结构相同的玩具图）；Windows 实际运行；Postgres 检查点；其他 Agent 程序。完整清单见主文档 §14。

## 注意

- `3_脚本/` 里的脚本，路径写死在沙箱（`/tmp/claude-0/...`）。它们是过程记录，在你的机器上不能直接运行。
- 沙箱里没有真实 Key。脚本里的 `sk-ant-api03-fake-local-mock-key`、`sk-mock-local` 是本地假模型用的占位值。
- 没有 commit，没有 push，也没有改你本地的仓库。
