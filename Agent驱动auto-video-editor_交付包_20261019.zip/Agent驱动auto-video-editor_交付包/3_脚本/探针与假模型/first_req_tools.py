import json, sys
rows = [json.loads(l) for l in open(sys.argv[1], encoding="utf-8")]
res = []
for r in rows:
    if not r.get("main"):
        continue
    names = [t["name"] for t in r["body"].get("tools", [])]
    res.append(len([n for n in names if n.startswith("mcp__")]))
print("mcp 工具数(每个请求):", res)
